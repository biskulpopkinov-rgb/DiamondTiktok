# Diamond TikTok

Демонстрационный Android-проект на Kotlin + Jetpack Compose.

## Сборка APK в облаке через GitHub Actions
1. Создайте репозиторий GitHub и загрузите в него содержимое этой папки.
2. Откройте вкладку Actions.
3. Выберите workflow `Build Diamond TikTok APK` и нажмите `Run workflow`.
4. После завершения откройте запуск workflow и скачайте artifact `DiamondTikTok-debug`.
5. Внутри архива будет `app-debug.apk`.

Это демонстрационная оболочка, а не официальный TikTok-клиент. Видеосервис, аккаунты и сетевые функции не реализованы.
