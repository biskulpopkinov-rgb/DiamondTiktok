package com.diamondtiktok.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF080B18)
private val Panel = Color(0xFF121A32)
private val Cyan = Color(0xFF54D9FF)
private val Violet = Color(0xFF7C5CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DiamondApp() }
    }
}

@Composable
fun DiamondApp() {
    var selected by remember { mutableStateOf("Главная") }
    var liked by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Cyan,
        secondary = Violet, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D1326)) {
                    listOf(
                        "Главная" to Icons.Default.Home,
                        "Друзья" to Icons.Default.People,
                        "Создать" to Icons.Default.AddCircle,
                        "Входящие" to Icons.Default.Mail,
                        "Профиль" to Icons.Default.Person
                    ).forEach { (name, icon) ->
                        NavigationBarItem(
                            selected = selected == name,
                            onClick = { selected = name },
                            icon = { Icon(icon, contentDescription = name) },
                            label = { Text(name, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).background(Night),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("◆", color = Cyan, fontSize = 28.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("DIAMOND", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                            Text("TIKTOK", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 4.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.Search, null, tint = Color.White)
                    }
                }
                item {
                    Text(
                        if (selected == "Главная") "Рекомендации" else selected,
                        color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold
                    )
                }
                item {
                    Box(
                        Modifier.fillMaxWidth().height(440.dp)
                            .background(Brush.linearGradient(listOf(Color(0xFF162D58), Color(0xFF34205F), Color(0xFF10182D))), RoundedCornerShape(24.dp))
                    ) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("◆", color = Cyan, fontSize = 76.sp)
                            Text("DIAMOND FEED", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Text("Демонстрационный экран", color = Color.LightGray, fontSize = 13.sp)
                        }
                        Column(Modifier.align(Alignment.BottomEnd).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(onClick = { liked = !liked }) {
                                Icon(Icons.Default.Favorite, null, tint = if (liked) Color(0xFFFF4F87) else Color.White)
                            }
                            Text(if (liked) "1" else "0", color = Color.White, fontSize = 12.sp)
                            IconButton(onClick = {}) { Icon(Icons.Default.ModeComment, null, tint = Color.White) }
                            IconButton(onClick = {}) { Icon(Icons.Default.Share, null, tint = Color.White) }
                        }
                        Text("@diamond_user  •  Пример публикации", color = Color.White, modifier = Modifier.align(Alignment.BottomStart).padding(16.dp))
                    }
                }
                item {
                    Text("Это демо-оболочка: настоящая загрузка видео, аккаунты и серверные функции пока не подключены.",
                        color = Color(0xFF9EABC8), fontSize = 12.sp)
                }
            }
        }
    }
}
